function alerta1(){
    alert("Usted apreto el boton 1")
}

function alerta2(){
    alert("Usted apreto el boton 2")
}

function alerta3(){
    alert("Usted apreto el boton 3")
}