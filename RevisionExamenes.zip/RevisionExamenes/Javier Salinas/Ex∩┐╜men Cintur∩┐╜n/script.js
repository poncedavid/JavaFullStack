function testimonialClick(){
    alert("Sorry, we haven't worked on editing this box :( \nWe hope to update this soon!");
}

function openMenu (){
    mainMenu.classList.toggle('main-menu--show');
    toggleMenu.classList.toggle('movement-menu--toggle');
    main.classList.toggle('movement-container--toggle');
    body.classList.toggle('movement-body-height--togle');
}