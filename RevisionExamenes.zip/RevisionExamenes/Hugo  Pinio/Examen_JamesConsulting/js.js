function leermas(){
    alert("Obteniendo mas Información")
}

function moreinfo(){
    alert("Generando Formulario para mas información")
}